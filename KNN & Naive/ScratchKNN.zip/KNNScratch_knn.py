import KNNScratch_fileReader
import random
import math
import matplotlib
import matplotlib.pyplot as plt

# count texts' appearance with a dictionary
def get_vector(text, d):
        vector = [0] * len(d)
        for i in d:
            for j in text:
                if i == j:              
                    vector[d.index(i)] += 1
        return vector
        
# calculate cosine similarity of two sentences
# with a dictionary
def get_cos_similarity(v1, v2,docNumTable,trainingSetSize,tf_idf):

        abs_A = 0
        abs_B = 0
        numerator = 0
        
        # Both vectors' length are same
        size = range(len(v1))
        for x in size:
                if tf_idf:
                        if docNumTable[x]==0:
                                docNumTable[x]+=1
                        v1[x]=v1[x]*(math.log(trainingSetSize / docNumTable[x]) + 1)
                
                numerator += v1[x]*v2[x]
                
                abs_A += v1[x]*v1[x]
                abs_B += v2[x]*v2[x]

        abs_A = abs_A**(0.5)
        abs_B = abs_B**(0.5)
        return numerator/((abs_A*abs_B)+1)

# get # neighbors, a test vector, vectors of data set
def classify(K, input_v, dataVset,docNumTable,trainingSetSize,tf_idf):
        
        sortedList = []
        spamConter = 0
        hamCounter = 0
        
        # calculate the similarity btw two vectors
        for v in dataVset:      
                # calculate cos similarity 
                # append the value and tag to the list 
                cs = get_cos_similarity(input_v, v[0],docNumTable,trainingSetSize,tf_idf)
                # put cosine similarity and the tag
                element = (cs, v[1])
                sortedList.append(element)
        
        # sort the list by cosine similarity
        sortedList.sort(key=lambda x: x[0], reverse=True)
        
        # compare with k neighbors from sorted list
        for i in range(K):
                if sortedList[i][1] == "Ham":
                        hamCounter+=1
                else:
                        spamConter+=1
        
        # show the result
        if spamConter < hamCounter:
                return "Ham"
        else:
                return "Spam"
                
def cross_validation(K, T, megaDoc,tf_idf):

        # shuffle elements in documents 
        random.shuffle(megaDoc)
        
        validationX = []
        validationAccuracyY = []
        validationPrecisionY = []
        validationRecallY = []
        
        # Cross-validation
        print("Cross validation")
        for i in range(0, 10):
        
                print("  [ Loop #", (i + 1), "]")

                testSetSize = int(len(megaDoc) * (1 / 10))
                startPos = int(len(megaDoc) * (i / 10))
                trainingSet = []
                testSet = []

                hamDocCount = 0
                spamDocCount = 0

                # Left loop
                for j in range(0, startPos):
                        if megaDoc[j][0] == "Ham":
                                hamDocCount += 1
                        else:
                                spamDocCount += 1
                        trainingSet.append(megaDoc[j])

                # Right loop
                for j in range(startPos + testSetSize, len(megaDoc)):
                        if megaDoc[j][0] == "Ham":
                                hamDocCount += 1
                        else:
                                spamDocCount += 1
                        trainingSet.append(megaDoc[j])
                
                # Extract the voca
                print("  generating vocabularies...")
                totalList = KNNScratch_fileReader.build_total_list(trainingSet)
                voca = KNNScratch_fileReader.build_t_vocabulary(totalList, T)
                print("  voca size:", len(voca))
                docNumTbl={}
                
                if tf_idf:
                # Get the table containing the number of documents per word
                        for doc in trainingSet:
                                wordTable = []
                                for word in doc[1]:
                                        if word in wordTable:
                                            continue
                                        else:
                                            wordTable.append(word)
                                            if word in docNumTbl:
                                                docNumTbl[word] += 1
                                            else:
                                                docNumTbl[word] = 1

                docNumTable=list(docNumTbl.values())
                result = ''
                tp = 0
                tn = 0
                fp = 0
                fn = 0
                
                # Add documents to test dataset
                for j in range(startPos, startPos + testSetSize):
                        testSet.append(megaDoc[j])

                
                testV = []
                trainingV = []
                
                print("  calculating vectors..")
                # calculate the vectors for test set in advance
                for test in testSet:
                    element = (get_vector(test[1], voca), test[0])
                    testV.append(element)
                        
                # calculate the vectors for training set in advance
                for data in trainingSet:
                        element = (get_vector(data[1], voca), data[0])
                        trainingV.append(element)       
                        
                print("  test data size:", len(testV))
                print("  tranining data size:", len(trainingV))
                print("  classifying..")
                for t_v in testV:
                        # plug test vector and training vector in
                        result = classify(K, t_v[0], trainingV,docNumTable,len(trainingSet),tf_idf)
                        if result == t_v[1]:
                                if t_v[1] == "Ham":
                                        tp += 1
                                else:
                                        tn += 1
                        else:
                                if t_v[1] == "Ham":
                                        fp += 1
                                else:
                                        fn += 1

                print("  True Positive =", tp)
                print("  True Negative =", tn)
                print("  False Positive =", fp)
                print("  False Negative =", fn)
                print("  Accuracy =", (tp + tn) / (fp + fn + tp + tn))
                #print("  Error =", 1 - (tp + tn) / (fp + fn + tp + tn))
                print("  Precision =", tp / (tp + fp))
                print("  Recall =", tp / (tp + fn))
                print("")
                validationX.append(i+1)
                validationAccuracyY.append((tp + tn) / (fp + fn + tp + tn))
                validationPrecisionY.append(tp / (tp + fp))
                validationRecallY.append(tp / (tp + fn))
                
        # plotting the points  
        ax1 = plt.subplot(3, 1, 1)
        plt.plot(validationX, validationAccuracyY, color='magenta', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='red', markersize=9, label = "Cross Validation")

        # naming the y axis 
        plt.ylabel('Accuracy')
        plt.ylim(min(validationAccuracyY) - 0.05, 1.0)

        ax2 = plt.subplot(312, sharex=ax1)
        plt.plot(validationX, validationPrecisionY, color='magenta', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='red', markersize=9, label = "Cross Validation")

        # naming the y axis 
        plt.ylabel('Precision')
        plt.ylim(min(validationPrecisionY) - 0.05, 1.0)

        ax3 = plt.subplot(313, sharex=ax1)
        plt.plot(validationX, validationRecallY, color='magenta', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='red', markersize=9, label = "Cross Validation")

        # naming the y axis 
        plt.ylabel('Recall')
        plt.ylim(min(validationRecallY) - 0.05, 1.0)

        # naming the x axis 
        plt.xlabel('C.V. = Loop') 
        plt.xlim(0, 10)

        # function to show the plot 
        plt.legend()
        plt.show() 
                

