import os

f = open("stopword.txt", "r")
stopwordtxt = f.read()
stopwords = stopwordtxt.split(',')

# Extract data per class (Ham and Spam)
def extract_data(words):
    myDict = {}
    count = 0
    for word in words:
        if word in myDict:
            myDict[word] = myDict[word] + 1
        else:
            myDict[word] = 1
        count += 1
    return myDict, count

# Extract data from both Ham and Spam classes
def build_vocabulary(words):
    vocaDict = {}
    for word in words:
        if word in vocaDict:
            vocaDict[word] = vocaDict[word] + 1
        else:
            vocaDict[word] = 1

    return vocaDict

def build_class_list(documents, toggle_t):
    hamList = []
    spamList = []
    for doc in documents:
        words = doc[1]

        if toggle_t == False:
            for word in words:
                if doc[0] == "Ham":
                    hamList.append(word)
                else:
                    spamList.append(word)
        else:
            for word in words:
                if word in totalDic:
                    if doc[0] == "Ham":
                        hamList.append(word)
                    else:
                        spamList.append(word)

    return hamList, spamList

def build_total_list(documents):
    totalList = []
    for doc in documents:
        words = doc[1]
        for word in words:
            totalList.append(word)
    return totalList
	
def build_t_vocabulary(words, t):
	vocaDict = {}
	for word in words:
		if word in vocaDict:
			vocaDict[word] = vocaDict[word] + 1
		else:
			vocaDict[word] = 1

	sortedList = sorted(vocaDict.items(), key=lambda x: x[1], reverse=True)

	newDict = []
	checker = 0
	for i in sortedList:
		# Append the element if it appears more than 50
		if i[1] >= 50:
			newDict.append(i[0])
			checker+=1
		else:
			break
		# if the dictionary takes t words,
		# stop appending
		if checker == t:
			break
			
	return newDict

def stemming(word):
    length = len(word)
    if length == 1:
        return False, word
    elif word.isdigit() == True:
        return False, word

    # if a words ends in ing, delete the ing unless the remaining word consists only of one letter or of th
    if word[length - 3:length] == "ing":
        word = word[0 : length - 3]
    # if a word ends with "ies" but not "eies" or "aies" then "ies -> y"
    elif word[length - 3:length] == "ies":
        if word[length-4] != 'e' and word[length-4] != 'a':
            word = word[0 : length - 3]
    # if a word ends in es, drop the s
    elif word[length - 2:length] == "es":
        word = word[0 : length - 1]
    # if a word ends with ed, preceded by a consonant, delete the ed unless this leaves only a single letter
    elif word[length - 2:length] == "ed" and length > 3:
        word = word[0 : length - 2]
    # if a word ends with a consonant other than s, followed by an s, then delete s
    elif word[length - 1:length] == "s":
        if word[length-2] != 'a' and word[length-2] != 'e' and word[length-2] != 'i' and word[length-2] != 'o' and word[length-2] != 'u':
            word = word[0 : length - 1]
    return True, word
	
# Store all documents and label them
def data_organize(dir):
	documentList = []
	for directories, subdirs, files in os.walk(dir):
		if (os.path.split(directories)[1] == 'ham'):
			for filename in files:
				with open(os.path.join(directories, filename), encoding="latin-1") as f:
					data = f.read()
					words = data.split()
					parsedData = []
					for word in words:
						if word in stopwords:
							continue
						else:
							stemmedWord = stemming(word)
							if(stemmedWord[0] == True):
								parsedData.append(stemmedWord[1])
							#parsedData.append(stemming(word))
							#parsedData.append(word)

					documentList.append(("Ham", parsedData))

		elif (os.path.split(directories)[1] == 'spam'):
			for filename in files:
				with open(os.path.join(directories, filename), encoding="latin-1") as f:
					data = f.read()
					words = data.split()
					parsedData = []
					for word in words:
						if word in stopwords:
							continue
						else:
							stemmedWord = stemming(word)
							if(stemmedWord[0] == True):
								parsedData.append(stemmedWord[1])
							#parsedData.append(stemming(word))
							#parsedData.append(word)

					documentList.append(("Spam", parsedData))
	return documentList