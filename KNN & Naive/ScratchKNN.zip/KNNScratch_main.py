#!/usr/bin/env python
# coding: utf-8

import os
import random
import KNNScratch_knn
import KNNScratch_fileReader

T = [20, 50, 100, 200, 500]
		
# main part

print("<K-NN Classifier>")
tf_idf = True
k = int(input("Type in the number 'K' for the number of neighbors: "))
t = int(input("Type in the number 'T' for the training set size: "))
runInputLoop2 = True
while runInputLoop2:
    inputString = input("Use 'Bag of Words' or 'TF-IDF'? (b / t): ")
    if inputString == 'B' or inputString == 'b':
        tf_idf = False
        runInputLoop2 = False
    elif inputString == 'T' or inputString == 't':
        tf_idf = True
        runInputLoop2 = False
    else:
        print("Wrong input! Please try again.\n")
# Get current directory
rootdir = os.getcwd()

# generate a mega doctument
print("Organizing raw data...")
megaDocument = KNNScratch_fileReader.data_organize(rootdir)

# run training and testing
KNNScratch_knn.cross_validation(k, t, megaDocument,tf_idf)
