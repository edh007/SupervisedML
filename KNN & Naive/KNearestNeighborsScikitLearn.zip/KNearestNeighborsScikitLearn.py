import math # To use log() function
import os
import random
import matplotlib
import matplotlib.pyplot as plt

from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import roc_auc_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score, recall_score, accuracy_score
from sklearn.metrics import confusion_matrix

from nltk.corpus import names
from nltk.stem.porter import PorterStemmer
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

import numpy as np
ps = PorterStemmer()
toggle_t_feature = False
T = 200
n = 6
tf_idf = True
K=1
def stemming(word):
    length = len(word)
    if length == 1:
        return False, word
    elif word.isdigit() == True:
        return False, word

    # if a words ends in ing, delete the ing unless the remaining word consists only of one letter or of th
    if word[length - 3:length] == "ing":
        word = word[0 : length - 3]
    # if a word ends with "ies" but not "eies" or "aies" then "ies -> y"
    elif word[length - 3:length] == "ies":
        if word[length-4] != 'e' and word[length-4] != 'a':
            word = word[0 : length - 3]
    # if a word ends in es, drop the s
    elif word[length - 2:length] == "es":
        word = word[0 : length - 1]
    # if a word ends with ed, preceded by a consonant, delete the ed unless this leaves only a single letter
    elif word[length - 2:length] == "ed" and length > 3:
        word = word[0 : length - 2]
    # if a word ends with a consonant other than s, followed by an s, then delete s
    elif word[length - 1:length] == "s":
        if word[length-2] != 'a' and word[length-2] != 'e' and word[length-2] != 'i' and word[length-2] != 'o' and word[length-2] != 'u':
            word = word[0 : length - 1]
    return True, word

# Main part

print("<K Nearest Neighbors Classifier>")
print("")

# Get user input for settings
runInputLoop1 = True
while runInputLoop1:
    inputString = input("Use 'T' most appearing words for attributes? (y / n): ")
    if inputString == 'Y' or inputString == 'y':
        toggle_t_feature = True
        runInputLoop1 = False
    elif inputString == 'N' or inputString == 'n':
        toggle_t_feature = False
        runInputLoop1 = False
    else:
        print("Wrong input! Please try again.\n")

if toggle_t_feature:
    T = int(input("Type in value for 'T' (T >= 25 recommended): "))

    




runInputLoop2 = True
while runInputLoop2:
    inputString = input("Use 'Bag of Words' or 'TF-IDF'? (b / t): ")
    if inputString == 'B' or inputString == 'b':
        tf_idf = False
        runInputLoop2 = False
    elif inputString == 'T' or inputString == 't':
        tf_idf = True
        runInputLoop2 = False
    else:
        print("Wrong input! Please try again.\n")

runInputLoop3 = True
while runInputLoop3:
    inputString = int(input("Type in value for 'K' (K >= 1 recommended): "))
    if inputString > 0:
        K=int(inputString)
        runInputLoop3 = False
    else:
        print("Wrong input! Please try again.\n")



f = open("stopword.txt", "r")
stopwordtxt = f.read()
stopwords = stopwordtxt.split(',')

# Get current directory
rootdir = os.getcwd()

documentList = []

# Store all documents and label them
print("Organizing raw data...")
for directories, subdirs, files in os.walk(rootdir):
    if (os.path.split(directories)[1] == 'ham'):
        for filename in files:
            with open(os.path.join(directories, filename), encoding="latin-1") as f:
                data = f.read()
                words = word_tokenize(data)
                parsedData = []
                for word in words:
                    if word in stopwords:
                        continue
                    else:
                        stemmedWord = stemming(word.lower())
                        if(stemmedWord[0] == True):
                            parsedData.append(ps.stem(stemmedWord[1]))
                        #parsedData.append(stemming(word))
                        #parsedData.append(word)

                documentList.append((parsedData, "Ham"))

    elif (os.path.split(directories)[1] == 'spam'):
        for filename in files:
            with open(os.path.join(directories, filename), encoding="latin-1") as f:
                data = f.read()
                words = word_tokenize(data)
                parsedData = []
                for word in words:
                    if word in stopwords:
                        continue
                    else:
                        stemmedWord = stemming(word.lower())
                        if(stemmedWord[0] == True):
                            parsedData.append(ps.stem(stemmedWord[1]))
                        #parsedData.append(stemming(word))
                        #parsedData.append(word)

                documentList.append((parsedData, "Spam"))
print("")

cleaned_emails = []
labels = []

if toggle_t_feature == False:
    for i in range(0, len(documentList)):
        labels.append(documentList[i][1])
        s = ' '
        s = s.join(documentList[i][0])
        cleaned_emails.append(s)
else:
    vocaDict = {}
    for i in range(0, len(documentList)):
        for word in documentList[i][0]:
            if word in vocaDict:
                vocaDict[word] = vocaDict[word] + 1
            else:
                vocaDict[word] = 1
    sortedList = sorted(vocaDict.items(), key=lambda x: x[1], reverse=True)
    totalList = {}
    for i in range(0, T):
        # Ignore the words whose counts are below 50
        if sortedList[i][1] < 50:
            break
        totalList[sortedList[i][0]] = sortedList[i][1]
    
    for i in range(0, len(documentList)):
        labels.append(documentList[i][1])
        wordList = []
        for word in documentList[i][0]:
            if word in totalList:
                wordList.append(word)
        s = ' '
        s = s.join(wordList)
        cleaned_emails.append(s)
    print("")

    # newDict = {}
    # for i in range(0, T):
    #     # Ignore the words whose counts are below 50
    #     if sortedList[i][1] < 50:
    #         break
    #     newDict[sortedList[i][0]] = sortedList[i][1]

# Define the independent variables as Xs.
Xs = np.array(cleaned_emails)

# Define the target (dependent) variable as Ys.
Ys = np.array(labels)

# Vectorize words - Turn the text numerical feature vectors,
# using the strategy of tokenization, counting and normalization.
vectorizer = CountVectorizer(min_df=50)
if tf_idf == True:
    vectorizer = TfidfVectorizer(sublinear_tf=True, min_df=50, stop_words='english')

Xs = vectorizer.fit_transform(Xs)

def get_most_important_features(vectorizer, clf, n=20):
    feature_names = vectorizer.get_feature_names()
    coefs_with_fns = sorted(zip(clf.coef_[0], feature_names))
    top = zip(coefs_with_fns[:n], coefs_with_fns[:-(n + 1):-1])
    return top
    # for (coef_1, fn_1), (coef_2, fn_2) in top:
    #     print "\t%.4f\t%-15s\t\t%.4f\t%-15s" % (coef_1, fn_1, coef_2, fn_2)

# def get_most_important_features(vectorizer, classifier, n=None):
#     feature_names = vectorizer.get_feature_names()
#     negativeN = n * -1
#     top_features = sorted(zip(classifier.coef_[0], feature_names))[negativeN:]

# if toggle_t_feature == True:
#     from nltk.classify import NaiveBayesClassifier
#     classifier = NaiveBayesClassifier.train(documentList)
#     classifier.show_most_informative_features(20)

randomX = []
validationX = []
randomAccuracyY = []
validationAccuracyY = []
randomPrecisionY = []
validationPrecisionY = []
randomRecallY = []
validationRecallY = []



print("<Cross Validation Test>")
print("")
# Cross-validation

from sklearn.model_selection import KFold 
from sklearn.model_selection import cross_val_score

# fix random seed for reproducibility 
seed = 7 
np.random.seed(seed)

clf = KNeighborsClassifier(K)
Y_translated = []
for i in range(len(Ys)):
    if Ys[i] == 'Ham':
        Y_translated.append(1)
    else:
        Y_translated.append(0)
Ys = np.array(Y_translated)
#clf.fit(X_train, y_train)
# model = KerasClassifier(build_fn=create_model, epochs=150, batch_size=10, verbose=0)
kfold = KFold(n_splits=10, shuffle=True, random_state=seed)
results = cross_val_score(clf, Xs, Ys, scoring='accuracy', cv=kfold)
precisionResult = cross_val_score(clf, Xs, Ys, scoring='precision', cv=kfold)
recallResult = cross_val_score(clf, Xs, Ys, scoring='recall', cv=kfold)

# cross_val_score(gnb, digits.data, digits.target, scoring='accuracy', cv=10).mean()
#print("Accuracy: " + str(results))
for i in range(0, len(results)):
    print("  [ Loop #", (i + 1), " ]")
    print("Accuracy: " + str(results[i]))
    print("  Accuracy =" + str(results[i]))
    print("  Precision =" + str(precisionResult[i]))
    print("  Recall =" + str(recallResult[i]))
    print("")
    validationX.append((i + 1)*10)
    validationAccuracyY.append(results[i])
    validationPrecisionY.append(results[i])
    validationRecallY.append(results[i])
    
import matplotlib
import matplotlib.pyplot as plt
ax1 = plt.subplot(3, 1, 1)
#plt.plot(randomX, randomAccuracyY, color='green', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='blue', markersize=9, label = "Random Subset")
plt.plot(validationX, validationAccuracyY, color='magenta', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='red', markersize=9, label = "Cross Validation")

if toggle_t_feature == True:
    title = "# of most appearing words T = "
    title += str(T)
    plt.title(title)

# naming the y axis 
plt.ylabel('Accuracy')
#plt.ylim(0.95, 1.0)
plt.ylim(min(randomAccuracyY + validationAccuracyY) - 0.05, 1.0)

ax2 = plt.subplot(312, sharex=ax1)
plt.plot(randomX, randomPrecisionY, color='green', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='blue', markersize=9, label = "Random Subset")
plt.plot(validationX, validationPrecisionY, color='magenta', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='red', markersize=9, label = "Cross Validation")

# naming the y axis 
plt.ylabel('Precision')
#plt.ylim(0.95, 1.0)
plt.ylim(min(randomPrecisionY + validationPrecisionY) - 0.05, 1.0)

ax3 = plt.subplot(313, sharex=ax1)
plt.plot(randomX, randomRecallY, color='green', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='blue', markersize=9, label = "Random Subset")
plt.plot(validationX, validationRecallY, color='magenta', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='red', markersize=9, label = "Cross Validation")

# naming the y axis 
plt.ylabel('Recall')
#plt.ylim(0.95, 1.0)
plt.ylim(min(randomRecallY + validationRecallY) - 0.05, 1.0)

# naming the x axis 
plt.xlabel('C.V. = Loop * 10 / R.S. = Percentage') 
plt.xlim(0, 100)

# function to show the plot 
plt.legend()
plt.show() 

# ### Examples
# email = ["Hello George, how about a game of tennis tomorrow?",
#          "Hello, click here if you want to satisfy your wife tonight",
#          "We offer free viagra!!! Click here now!!!",
#          "Dear Sara, I prepared the annual report. Please check the attachment.",
#          "Hi David, will we go for cinema tonight?",
#          "Best holidays offers only here!!!"]

# examples = vectorizer.transform(email)
# predictions = clf.predict(examples)
# predictions


input(print("Press Enter to exit"))
