import math
import os
import random
import matplotlib
import matplotlib.pyplot as plt

from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import roc_auc_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score, recall_score, accuracy_score
from sklearn.metrics import confusion_matrix

from nltk.corpus import names
from nltk.stem.porter import PorterStemmer
from nltk.tokenize import word_tokenize

import numpy as np

toggle_t_feature = False
T = 200
n = 6
tf_idf = True

def stemming(word):
    length = len(word)
    if length == 1:
        return False, word
    elif word.isdigit() == True:
        return False, word

    # if a words ends in ing, delete the ing unless the remaining word consists only of one letter or of th
    if word[length - 3:length] == "ing":
        word = word[0 : length - 3]
    # if a word ends with "ies" but not "eies" or "aies" then "ies -> y"
    elif word[length - 3:length] == "ies":
        if word[length-4] != 'e' and word[length-4] != 'a':
            word = word[0 : length - 3]
    # if a word ends in es, drop the s
    elif word[length - 2:length] == "es":
        word = word[0 : length - 1]
    # if a word ends with ed, preceded by a consonant, delete the ed unless this leaves only a single letter
    elif word[length - 2:length] == "ed" and length > 3:
        word = word[0 : length - 2]
    # if a word ends with a consonant other than s, followed by an s, then delete s
    elif word[length - 1:length] == "s":
        if word[length-2] != 'a' and word[length-2] != 'e' and word[length-2] != 'i' and word[length-2] != 'o' and word[length-2] != 'u':
            word = word[0 : length - 1]
    return True, word

# Main
print("<Naive Bayes Classifier>")
print("")

# Get user input for settings
runInputLoop1 = True
while runInputLoop1:
    inputString = input("Use 'T' most appearing words for attributes? (y / n): ")
    if inputString == 'Y' or inputString == 'y':
        toggle_t_feature = True
        runInputLoop1 = False
    elif inputString == 'N' or inputString == 'n':
        toggle_t_feature = False
        runInputLoop1 = False
    else:
        print("Wrong input! Please try again.\n")

if toggle_t_feature:
    T = int(input("Type in value for 'T' (T >= 25 recommended): "))

runInputLoop2 = True
while runInputLoop2:
    inputString = input("Use 'Bag of Words' or 'TF-IDF'? (b / t): ")
    if inputString == 'B' or inputString == 'b':
        tf_idf = False
        runInputLoop2 = False
    elif inputString == 'T' or inputString == 't':
        tf_idf = True
        runInputLoop2 = False
    else:
        print("Wrong input! Please try again.\n")

n = int(input("Type in the number 'n' for the number of random subset loops (n > 5 recommended): "))
print("")

f = open("stopword.txt", "r")
stopwordtxt = f.read()
stopwords = stopwordtxt.split(',')

# Get current directory
rootdir = os.getcwd()

documentList = []

# Store all documents and label them
print("Organizing raw data...")
for directories, subdirs, files in os.walk(rootdir):
    if (os.path.split(directories)[1] == 'ham'):
        for filename in files:
            with open(os.path.join(directories, filename), encoding="latin-1") as f:
                data = f.read()
                words = data.split()
                parsedData = []
                for word in words:
                    if word in stopwords:
                        continue
                    else:
                        stemmedWord = stemming(word.lower())
                        if(stemmedWord[0] == True):
                            parsedData.append(stemmedWord[1])
                        #parsedData.append(stemming(word))
                        #parsedData.append(word)

                documentList.append((parsedData, "Ham"))

    elif (os.path.split(directories)[1] == 'spam'):
        for filename in files:
            with open(os.path.join(directories, filename), encoding="latin-1") as f:
                data = f.read()
                words = data.split()
                parsedData = []
                for word in words:
                    if word in stopwords:
                        continue
                    else:
                        stemmedWord = stemming(word.lower())
                        if(stemmedWord[0] == True):
                            parsedData.append(stemmedWord[1])
                        #parsedData.append(stemming(word))
                        #parsedData.append(word)

                documentList.append((parsedData, "Spam"))
print("")

cleaned_emails = []
labels = []

if toggle_t_feature == False:
    for i in range(0, len(documentList)):
        labels.append(documentList[i][1])
        s = ' '
        s = s.join(documentList[i][0])
        cleaned_emails.append(s)
else:
    vocaDict = {}
    for i in range(0, len(documentList)):
        for word in documentList[i][0]:
            if word in vocaDict:
                vocaDict[word] = vocaDict[word] + 1
            else:
                vocaDict[word] = 1
    sortedList = sorted(vocaDict.items(), key=lambda x: x[1], reverse=True)
    totalList = {}
    for i in range(0, T):
        # Ignore the words whose counts are below 50
        if sortedList[i][1] < 50:
            break
        totalList[sortedList[i][0]] = sortedList[i][1]
    
    for i in range(0, len(documentList)):
        labels.append(documentList[i][1])
        wordList = []
        for word in documentList[i][0]:
            if word in totalList:
                wordList.append(word)
        s = ' '
        s = s.join(wordList)
        cleaned_emails.append(s)
    print("")

# Define the independent variables as Xs.
Xs = np.array(cleaned_emails)

# Define the target (dependent) variable as Ys.
Ys = np.array(labels)

# Vectorize words
vectorizer = CountVectorizer()
if tf_idf == True:
    vectorizer = TfidfVectorizer(sublinear_tf=True, stop_words='english')

Xs = vectorizer.fit_transform(Xs)

randomX = []
validationX = []
randomAccuracyY = []
validationAccuracyY = []
randomPrecisionY = []
validationPrecisionY = []
randomRecallY = []
validationRecallY = []

print("<Random Subset Test>")
print("")

# Random Subset
for i in range(1, 5):

    accuracy = 0
    precision = 0
    recall = 0
    accuracy2 = 0
    for i2 in range(0, n):
        # Create a train/test split using 20% test size.
        X_train, X_test, y_train, y_test = train_test_split(Xs,
                                                            Ys,
                                                            test_size=(i / 5),
                                                            shuffle=True,
                                                            random_state=0,
                                                            stratify=Ys)

        feature_names = vectorizer.get_feature_names()

        #print("Number of different words: {0}".format(len(feature_names)))
        #print("Word example: {0}".format(feature_names[5369]))

        # Check the split printing the shape of each set.
        #print(X_train.shape, y_train.shape)
        #print(X_test.shape, y_test.shape)

        # ### Train a Classifier
        # Train a Naive Bayes classifier and evaluate the performance with the accuracy score.
        clf = MultinomialNB() # Create classifier.
        clf.fit(X_train, y_train) # Fit the classifier on the training features and labels.
        pred = clf.predict(X_test) # Make prediction - Store predictions in a list named pred.

        accuracy += clf.score(X_test, y_test)

        y_true, y_pred = [], []
        for index in range(0, len(pred)):
            if y_test[index] == 'Spam':
                y_true.append(0)
            else:
                y_true.append(1)
            if pred[index] == 'Spam':
                y_pred.append(0)
            else:
                y_pred.append(1)
                
        accuracy2 += accuracy_score(y_true, y_pred)
        precision += precision_score(y_true, y_pred)
        recall += recall_score(y_true, y_pred)

        
    print("  [ Percentage =", i*20, "% ]")
    print("  Accuracy =", accuracy / n)
    print("  Precision =", precision / n)
    print("  Recall =", recall / n)
    #print("  Accuracy2 =", accuracy2 / n)
    print("")
    randomX.append(i * 20)
    randomAccuracyY.append(accuracy / n)
    randomPrecisionY.append(precision / n)
    randomRecallY.append(recall / n)

# Read in sample emails here
sampleList = []
for directories, subdirs, files in os.walk(rootdir):
    if os.path.split(directories)[1] == 'SampleHam':
        for filename in files:
            with open(os.path.join(directories, filename), encoding="latin-1") as f:
                data = f.read()
                words = data.split()
                parsedData = []
                for word in words:
                    if word in stopwords:
                        continue
                    else:
                        stemmedWord = stemming(word)
                        if(stemmedWord[0] == True):
                            parsedData.append(stemmedWord[1])

                sampleList.append((parsedData, "Ham"))

    elif os.path.split(directories)[1] == 'SampleSpam':
        for filename in files:
            with open(os.path.join(directories, filename), encoding="latin-1") as f:
                data = f.read()
                words = data.split()
                parsedData = []
                for word in words:
                    if word in stopwords:
                        continue
                    else:
                        stemmedWord = stemming(word)
                        if (stemmedWord[0] == True):
                            parsedData.append(stemmedWord[1])

                sampleList.append((parsedData, "Spam"))

Xt, Yt = [], []
for i in range(0, len(sampleList)):
    Yt.append(sampleList[i][1])
    s = ' '
    s = s.join(sampleList[i][0])
    Xt.append(s)

X_test = np.array(Xt) # Define the independent variables as Xs.
Y_test = np.array(Yt) # Define the target (dependent) variable as Ys.
X_test = vectorizer.fit_transform(X_test)

accuracy = 0
precision = 0
recall = 0
accuracy2 = 0

for i2 in range(0, n):
    clf = MultinomialNB() # Create classifier.
    clf.fit(X_test, Y_test) # Fit the classifier on the training features and labels.
    pred = clf.predict(X_test) # Make prediction - Store predictions in a list named pred.
    #print("Accuracy: {}".format(clf.score(X_test, y_test))) # Calculate the accuracy on the test data.
    accuracy += clf.score(X_test, Y_test)

    y_true, y_pred = [], []
    for index in range(0, len(pred)):
        if Y_test[index] == 'Spam':
            y_true.append(0)
        else:
            y_true.append(1)
        if pred[index] == 'Spam':
            y_pred.append(0)
        else:
            y_pred.append(1)

    accuracy2 += accuracy_score(y_true, y_pred)
    precision += precision_score(y_true, y_pred)
    recall += recall_score(y_true, y_pred)
    # print("***CONFUSION MATRIX STR***")
    # print(confusion_matrix(y_true, y_pred))
    # print("***CONFUSION MATRIX END***")
print("  [ Percentage =", 100, "% ]")
print("  Accuracy =", accuracy / n)
print("  Precision =", precision / n)
print("  Recall =", recall / n)
#print("  Accuracy2 =", accuracy2 / n)
print("")
randomX.append(100)
if(accuracy > 0):
    randomAccuracyY.append(accuracy / n)
else:
    randomAccuracyY.append(1)
if(precision > 0):
    randomPrecisionY.append(precision / n)
else:
    randomPrecisionY.append(1)
if(recall > 0):
    randomRecallY.append(recall / n)
else:
    randomRecallY.append(1)

print("<Cross Validation Test>")
print("")
# Cross-validation

from sklearn.model_selection import KFold 
from sklearn.model_selection import cross_val_score

# fix random seed for reproducibility 
seed = 7 
np.random.seed(seed)

clf = MultinomialNB()
Y_translated = []
for i in range(len(Ys)):
    if Ys[i] == 'Ham':
        Y_translated.append(1)
    else:
        Y_translated.append(0)
Ys = np.array(Y_translated)

kfold = KFold(n_splits=10, shuffle=True, random_state=seed)
results = cross_val_score(clf, Xs, Ys, scoring='accuracy', cv=kfold)
precisionResult = cross_val_score(clf, Xs, Ys, scoring='precision', cv=kfold)
recallResult = cross_val_score(clf, Xs, Ys, scoring='recall', cv=kfold)

for i in range(0, len(results)):
    print("  [ Loop #", (i + 1), " ]")
    print("  Accuracy =" + str(results[i]))
    print("  Precision =" + str(precisionResult[i]))
    print("  Recall =" + str(recallResult[i]))
    print("")
    validationX.append((i + 1)*10)
    validationAccuracyY.append(results[i])
    validationPrecisionY.append(results[i])
    validationRecallY.append(results[i])

import matplotlib
import matplotlib.pyplot as plt

# plotting the points  
ax1 = plt.subplot(3, 1, 1)
plt.plot(randomX, randomAccuracyY, color='green', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='blue', markersize=9, label = "Random Subset")
plt.plot(validationX, validationAccuracyY, color='magenta', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='red', markersize=9, label = "Cross Validation")

if toggle_t_feature == True:
    title = "# of most appearing words T = "
    title += str(T)
    plt.title(title)

# naming the y axis 
plt.ylabel('Accuracy')
#plt.ylim(0.95, 1.0)
plt.ylim(min(randomAccuracyY + validationAccuracyY) - 0.05, 1.0)

ax2 = plt.subplot(312, sharex=ax1)
plt.plot(randomX, randomPrecisionY, color='green', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='blue', markersize=9, label = "Random Subset")
plt.plot(validationX, validationPrecisionY, color='magenta', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='red', markersize=9, label = "Cross Validation")

# naming the y axis 
plt.ylabel('Precision')
#plt.ylim(0.95, 1.0)
plt.ylim(min(randomPrecisionY + validationPrecisionY) - 0.05, 1.0)

ax3 = plt.subplot(313, sharex=ax1)
plt.plot(randomX, randomRecallY, color='green', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='blue', markersize=9, label = "Random Subset")
plt.plot(validationX, validationRecallY, color='magenta', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='red', markersize=9, label = "Cross Validation")

# naming the y axis 
plt.ylabel('Recall')
#plt.ylim(0.95, 1.0)
plt.ylim(min(randomRecallY + validationRecallY) - 0.05, 1.0)

# naming the x axis 
plt.xlabel('C.V. = Loop * 10 / R.S. = Percentage') 
plt.xlim(0, 100)

# function to show the plot 
plt.legend()
plt.show() 

input(print("Press Enter to exit"))