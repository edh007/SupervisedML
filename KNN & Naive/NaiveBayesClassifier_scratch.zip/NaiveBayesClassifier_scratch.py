import math # To use log() function
import os
import random
import matplotlib
import matplotlib.pyplot as plt

toggle_t_feature = False
T = 200
n = 6
tf_idf = True
docNumTable = {}

def build_total_list(documents):
    totalList = []
    for doc in documents:
        words = doc[1]
        for word in words:
            totalList.append(word)
    return totalList

# Extract data from a certain portion of documents
def build_class_list(documents, toggle_t):
    hamList = []
    spamList = []
    for doc in documents:
        words = doc[1]

        if toggle_t == False:
            for word in words:
                if doc[0] == "Ham":
                    hamList.append(word)
                else:
                    spamList.append(word)
        else:
            for word in words:
                if word in totalDic:
                    if doc[0] == "Ham":
                        hamList.append(word)
                    else:
                        spamList.append(word)

    return hamList, spamList

def stemming(word):
    length = len(word)
    if length == 1:
        return False, word
    elif word.isdigit() == True:
        return False, word

    # if a words ends in ing, delete the ing unless the remaining word consists only of one letter or of th
    if word[length - 3:length] == "ing":
        word = word[0 : length - 3]
    # if a word ends with "ies" but not "eies" or "aies" then "ies -> y"
    elif word[length - 3:length] == "ies":
        if word[length-4] != 'e' and word[length-4] != 'a':
            word = word[0 : length - 3]
    # if a word ends in es, drop the s
    elif word[length - 2:length] == "es":
        word = word[0 : length - 1]
    # if a word ends with ed, preceded by a consonant, delete the ed unless this leaves only a single letter
    elif word[length - 2:length] == "ed" and length > 3:
        word = word[0 : length - 2]
    # if a word ends with a consonant other than s, followed by an s, then delete s
    elif word[length - 1:length] == "s":
        if word[length-2] != 'a' and word[length-2] != 'e' and word[length-2] != 'i' and word[length-2] != 'o' and word[length-2] != 'u':
            word = word[0 : length - 1]
    return True, word

# Extract data per class (Ham and Spam)
def extract_data(words):
    myDict = {}
    for word in words:
        if word in myDict:
            myDict[word] = myDict[word] + 1
        else:
            myDict[word] = 1
    return myDict

# Extract data from both Ham and Spam classes
def build_vocabulary(words):
    vocaDict = {}
    for word in words:
        if word in vocaDict:
            vocaDict[word] = vocaDict[word] + 1
        else:
            vocaDict[word] = 1

    return vocaDict

#
def build_t_vocabulary(words, t):
    vocaDict = {}
    for word in words:
        if word in vocaDict:
            vocaDict[word] = vocaDict[word] + 1
        else:
            vocaDict[word] = 1

    sortedList = sorted(vocaDict.items(), key=lambda x: x[1], reverse=True)

    newDict = {}
    for i in range(0, T):
        # Ignore the words whose counts are below 50
        if sortedList[i][1] < 50:
            break
        newDict[sortedList[i][0]] = sortedList[i][1]

    return newDict

# Classify given document
def classify(inputDoc, hamDict, hamWordCount, spamDict, spamWordCount, wordVolume, docCount, hamDocCount, spamDocCount, docNumTable):
    # Get priors for each class first
    pHam = math.log(hamDocCount / docCount)
    pSpam = math.log(spamDocCount / docCount)

    for word in inputDoc:
        # If there is no such word in the vocabulary, then do nothing
        if word not in totalDic:
            continue

        # Calculate conditional probabilities separately for Ham and Spam
        # Use Log addition and Laplace Smoothing

        # If there exists the same word in Ham data documents
        if word in hamDict:
            if not tf_idf:
                pHam += math.log((hamDict[word] + 1) / (hamWordCount + wordVolume))
            else:
                pHam += math.log((hamDict[word] * math.log(docCount / docNumTable[word]) + 1) / (hamWordCount + wordVolume))
        else:
            pHam += math.log(1 / (hamWordCount + wordVolume))

        # If there exists the same word in Spam data documents
        if word in spamDict:
            if not tf_idf:
                pSpam += math.log((spamDict[word] + 1) / (spamWordCount + wordVolume))
            else:
                pSpam += math.log((spamDict[word] * math.log(docCount / docNumTable[word]) + 1) / (spamWordCount + wordVolume))
        else:
            pSpam += math.log(1 / (spamWordCount + wordVolume))
#
    if pHam > pSpam:
        return "Ham"
    else:
        return "Spam"


# Main part

print("<Naive Bayes Classifier>")
print("")

# Get user input for settings
runInputLoop1 = True
while runInputLoop1:
    inputString = input("Use 'T' most appearing words for attributes? (y / n): ")
    if inputString == 'Y' or inputString == 'y':
        toggle_t_feature = True
        runInputLoop1 = False
    elif inputString == 'N' or inputString == 'n':
        toggle_t_feature = False
        runInputLoop1 = False
    else:
        print("Wrong input! Please try again.\n")

if toggle_t_feature:
    T = int(input("Type in value for 'T' (T >= 25 recommended): "))

runInputLoop2 = True
while runInputLoop2:
    inputString = input("Use 'Bag of Words' or 'TF-IDF'? (b / t): ")
    if inputString == 'B' or inputString == 'b':
        tf_idf = False
        runInputLoop2 = False
    elif inputString == 'T' or inputString == 't':
        tf_idf = True
        runInputLoop2 = False
    else:
        print("Wrong input! Please try again.\n")

n = int(input("Type in the number 'n' for the number of random subset loops (n > 5 recommended): "))
print("")

f = open("stopword.txt", "r")
stopwordtxt = f.read()
stopwords = stopwordtxt.split(',')

# Get current directory
rootdir = os.getcwd()

documentList = []

# Store all documents and label them
print("Organizing raw data...")
for directories, subdirs, files in os.walk(rootdir):
    if (os.path.split(directories)[1] == 'ham'):
        for filename in files:
            with open(os.path.join(directories, filename), encoding="latin-1") as f:
                data = f.read()
                words = data.split()
                parsedData = []
                for word in words:
                    if word in stopwords:
                        continue
                    else:
                        stemmedWord = stemming(word)
                        if(stemmedWord[0] == True):
                            parsedData.append(stemmedWord[1])
                        #parsedData.append(stemming(word))
                        #parsedData.append(word)

                documentList.append(("Ham", parsedData))

    elif (os.path.split(directories)[1] == 'spam'):
        for filename in files:
            with open(os.path.join(directories, filename), encoding="latin-1") as f:
                data = f.read()
                words = data.split()
                parsedData = []
                for word in words:
                    if word in stopwords:
                        continue
                    else:
                        stemmedWord = stemming(word)
                        if(stemmedWord[0] == True):
                            parsedData.append(stemmedWord[1])
                        #parsedData.append(stemming(word))
                        #parsedData.append(word)

                documentList.append(("Spam", parsedData))
print("")

print("Total # of documents = ", len(documentList))
print("")

# shuffle elements in documents
#random.shuffle(documentList)
randomX = []
validationX = []
randomAccuracyY = []
validationAccuracyY = []
randomPrecisionY = []
validationPrecisionY = []
randomRecallY = []
validationRecallY = []

print("<Random Subset Test>")
print("")
# Random subsets part (20%, 40%, 60%, 80%, 100%)
# No option for 100% for now...
for i in range(1, 5):

    tp = 0
    tn = 0
    fp = 0
    fn = 0
    portion = int(len(documentList) * (i / 5))

    # Run the loop for n times for generalization
    for i2 in range(0, n):
        # shuffle elements in documents
        random.shuffle(documentList)

        subDocuments = []

        hamDocCount = 0
        spamDocCount = 0
        for j in range(0, portion):
            if documentList[j][0] == "Ham":
                hamDocCount += 1
            else:
                spamDocCount += 1
            subDocuments.append(documentList[j])

        if toggle_t_feature == False:
            hamList, spamList = build_class_list(subDocuments, False)
            combinedList = hamList + spamList

            totalDic = build_vocabulary(combinedList)
            wordVolume = len(totalDic)

        else:
            totalList = build_total_list(subDocuments)
            totalDic = build_t_vocabulary(totalList, T)
            wordVolume = len(totalDic)

            hamList, spamList = build_class_list(subDocuments, True)

        hamDict = extract_data(hamList)
        spamDict = extract_data(spamList)

        docNumTable.clear()
        if tf_idf:
            # Get the table containing the number of documents per word
            for doc in subDocuments:
                wordTable = []
                for word in doc[1]:
                    if word in wordTable:
                        continue
                    else:
                        wordTable.append(word)
                        if word in docNumTable:
                            docNumTable[word] += 1
                        else:
                            docNumTable[word] = 1
            #print("")

        result = ''

        for j in range(portion, len(documentList)):
            result = classify(documentList[j][1], hamDict, len(hamList), spamDict, len(spamList), wordVolume, portion,
                              hamDocCount, spamDocCount, docNumTable)
            if result == documentList[j][0]:
                if documentList[j][0] == "Ham":
                    tp += 1
                else:
                    tn += 1
            else:
                if documentList[j][0] == "Ham":
                    fp += 1
                else:
                    fn += 1

    # Taking the average of each result
    tp = int(tp / n)
    tn = int(tn / n)
    fp = int(fp / n)
    fn = int(fn / n)

    print("  [ Percentage =", i*20, "% ]")
    print("  True Positive =", tp)
    print("  True Negative =", tn)
    print("  False Positive =", fp)
    print("  False Negative =", fn)
    print("  Accuracy =", (tp + tn) / (fp + fn + tp + tn))
    #print("  Error =", 1 - (tp + tn) / (fp + fn + tp + tn))
    print("  Precision =", tp / (tp + fp))
    print("  Recall =", tp / (tp + fn))
    print("")
    randomX.append(i * 20)
    randomAccuracyY.append((tp + tn) / (fp + fn + tp + tn))
    randomPrecisionY.append(tp / (tp + fp))
    randomRecallY.append(tp / (tp + fn))

# Subset of 100% of the training data
#subDocuments = []
hamDocCount = 0
spamDocCount = 0

for j in range(0, len(documentList)):
    if documentList[j][0] == "Ham":
        hamDocCount += 1
    else:
        spamDocCount += 1
    #subDocuments.append(documentList[j])

if toggle_t_feature == False:
    #hamList, spamList = build_class_list(subDocuments, False)
    hamList, spamList = build_class_list(documentList, False)
    combinedList = hamList + spamList
    totalDic = build_vocabulary(combinedList)
    wordVolume = len(totalDic)
else:
    #totalList = build_total_list(subDocuments)
    totalList = build_total_list(documentList)
    totalDic = build_t_vocabulary(totalList, T)
    wordVolume = len(totalDic)
    #hamList, spamList = build_class_list(subDocuments, True)
    hamList, spamList = build_class_list(documentList, True)

hamDict = extract_data(hamList)
spamDict = extract_data(spamList)

docNumTable.clear()
if tf_idf:
    # Get the table containing the number of documents per word
    #for doc in subDocuments:
    for doc in documentList:
        wordTable = []
        for word in doc[1]:
            if word in wordTable:
                continue
            else:
                wordTable.append(word)
                if word in docNumTable:
                    docNumTable[word] += 1
                else:
                    docNumTable[word] = 1
    print("")

# Read in sample emails here
sampleList = []
for directories, subdirs, files in os.walk(rootdir):
    if os.path.split(directories)[1] == 'SampleHam':
        for filename in files:
            with open(os.path.join(directories, filename), encoding="latin-1") as f:
                data = f.read()
                words = data.split()
                parsedData = []
                for word in words:
                    if word in stopwords:
                        continue
                    else:
                        stemmedWord = stemming(word)
                        if(stemmedWord[0] == True):
                            parsedData.append(stemmedWord[1])

                sampleList.append(("Ham", parsedData))

    elif os.path.split(directories)[1] == 'SampleSpam':
        for filename in files:
            with open(os.path.join(directories, filename), encoding="latin-1") as f:
                data = f.read()
                words = data.split()
                parsedData = []
                for word in words:
                    if word in stopwords:
                        continue
                    else:
                        stemmedWord = stemming(word)
                        if (stemmedWord[0] == True):
                            parsedData.append(stemmedWord[1])

                sampleList.append(("Spam", parsedData))

tp = 0
tn = 0
fp = 0
fn = 0

# Input a few sample emails here
for sampleDoc in sampleList:
    result = classify(sampleDoc[1], hamDict, len(hamList), spamDict, len(spamList), wordVolume, len(documentList),
                      hamDocCount, spamDocCount, docNumTable)
    if result == sampleDoc[0]:
        if sampleDoc[0] == "Ham":
            tp += 1
        else:
            tn += 1
    else:
        if sampleDoc[0] == "Ham":
            fp += 1
        else:
            fn += 1

print("  [ Percentage = 100 % (Tested with custom emails) ]")
print("  True Positive =", tp)
print("  True Negative =", tn)
print("  False Positive =", fp)
print("  False Negative =", fn)
print("  Accuracy =", (tp + tn) / (fp + fn + tp + tn))
if (tp + fp) > 0:
    print("  Precision =", tp / (tp + fp))
else:
    print("  Precision = N/A")
if (tp + fn) > 0:
    print("  Recall =", tp / (tp + fn))
else:
    print("  Recall = N/A")
print("")
randomX.append(100)
randomAccuracyY.append((tp + tn) / (fp + fn + tp + tn))
if (tp + fp) > 0:
    randomPrecisionY.append(tp / (tp + fp))
else:
    randomPrecisionY.append(-1)
if (tp + fn) > 0:
    randomRecallY.append(tp / (tp + fn))
else:
    randomRecallY.append(-1)

print("")

# shuffle elements in documents
random.shuffle(documentList)

print("<Cross Validation Test>")
print("")
# Cross-validation
for i in range(0, 10):

    testSetSize = int(len(documentList) * (1 / 10))
    startPos = int(len(documentList) * (i / 10))
    trainingSet = []
    testSet = []

    hamDocCount = 0
    spamDocCount = 0

    # Left loop
    for j in range(0, startPos):
        if documentList[j][0] == "Ham":
            hamDocCount += 1
        else:
            spamDocCount += 1
        trainingSet.append(documentList[j])

    # Right loop
    for j in range(startPos + testSetSize, len(documentList)):
        if documentList[j][0] == "Ham":
            hamDocCount += 1
        else:
            spamDocCount += 1
        trainingSet.append(documentList[j])

    if toggle_t_feature == False:
        hamList, spamList = build_class_list(trainingSet, False)
        combinedList = hamList + spamList

        totalDic = build_vocabulary(combinedList)
        wordVolume = len(totalDic)
    else:
        totalList = build_total_list(trainingSet)
        totalDic = build_t_vocabulary(totalList, T)
        wordVolume = len(totalDic)

        hamList, spamList = build_class_list(subDocuments, True)

    hamDict = extract_data(hamList)
    spamDict = extract_data(spamList)

    docNumTable.clear()
    if tf_idf:
        # Get the table containing the number of documents per word
        for doc in trainingSet:
            wordTable = []
            for word in doc[1]:
                if word in wordTable:
                    continue
                else:
                    wordTable.append(word)
                    if word in docNumTable:
                        docNumTable[word] += 1
                    else:
                        docNumTable[word] = 1
        print("")

    result = ''
    tp = 0
    tn = 0
    fp = 0
    fn = 0

    # Add documents to test dataset
    for j in range(startPos, startPos + testSetSize):
        testSet.append(documentList[j])

    for doc in testSet:
        result = classify(doc[1], hamDict, len(hamList), spamDict, len(spamList), wordVolume, len(trainingSet),
                          hamDocCount, spamDocCount, docNumTable)
        if result == doc[0]:
            if doc[0] == "Ham":
                tp += 1
            else:
                tn += 1
        else:
            if doc[0] == "Ham":
                fp += 1
            else:
                fn += 1

    print("  [ Loop #", (i + 1), " ]")
    print("  True Positive =", tp)
    print("  True Negative =", tn)
    print("  False Positive =", fp)
    print("  False Negative =", fn)
    print("  Accuracy =", (tp + tn) / (fp + fn + tp + tn))
    #print("  Error =", 1 - (tp + tn) / (fp + fn + tp + tn))
    print("  Precision =", tp / (tp + fp))
    print("  Recall =", tp / (tp + fn))
    print("")
    validationX.append((i + 1)*10)
    validationAccuracyY.append((tp + tn) / (fp + fn + tp + tn))
    validationPrecisionY.append(tp / (tp + fp))
    validationRecallY.append(tp / (tp + fn))

# plotting the points  
ax1 = plt.subplot(3, 1, 1)
plt.plot(randomX, randomAccuracyY, color='green', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='blue', markersize=9, label = "Random Subset")
plt.plot(validationX, validationAccuracyY, color='magenta', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='red', markersize=9, label = "Cross Validation")

if toggle_t_feature == True:
    title = "# of most appearing words T = "
    title += str(T)
    plt.title(title)

# naming the y axis 
plt.ylabel('Accuracy')
#plt.ylim(0.95, 1.0)
plt.ylim(min(randomAccuracyY + validationAccuracyY) - 0.05, 1.0)

ax2 = plt.subplot(312, sharex=ax1)
plt.plot(randomX, randomPrecisionY, color='green', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='blue', markersize=9, label = "Random Subset")
plt.plot(validationX, validationPrecisionY, color='magenta', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='red', markersize=9, label = "Cross Validation")

# naming the y axis 
plt.ylabel('Precision')
#plt.ylim(0.95, 1.0)
plt.ylim(min(randomPrecisionY + validationPrecisionY) - 0.05, 1.0)

ax3 = plt.subplot(313, sharex=ax1)
plt.plot(randomX, randomRecallY, color='green', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='blue', markersize=9, label = "Random Subset")
plt.plot(validationX, validationRecallY, color='magenta', linestyle='dashed', linewidth = 3, marker='o', markerfacecolor='red', markersize=9, label = "Cross Validation")

# naming the y axis 
plt.ylabel('Recall')
#plt.ylim(0.95, 1.0)
plt.ylim(min(randomRecallY + validationRecallY) - 0.05, 1.0)

# naming the x axis 
plt.xlabel('C.V. = Loop * 10 / R.S. = Percentage') 
plt.xlim(0, 100)

# function to show the plot 
plt.legend()
plt.show() 

input(print("End of the program"))